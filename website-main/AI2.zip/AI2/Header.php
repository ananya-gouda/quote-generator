<div id="topbar" class="d-none d-lg-flex align-items-center fixed-top">
    <div class="container d-flex">
        <div class="contact-info mr-auto">
            <i class="icofont-envelope"></i> <a href="mailto:contact@example.com">contact@example.com</a>
            <i class="icofont-phone"></i> +1 5589 55488 55
        </div>
        <div class="social-links">
            <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
            <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
            <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
            <a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
        </div>
    </div>
</div>
<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">
        <h1 class="logo mr-auto"><a href="./">AI</a></h1>
        <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt=""></a>-->
        <nav class="nav-menu d-none d-lg-block">
            <ul>
                <li class="active">
                    <a href="./">Home</a>
                </li>
                <li><a href="Solutions.php">Solutions</a></li>
                <li><a href="About-Us.php">About Us</a></li>
                <li><a href="Services.php">Services</a></li>
                <li><a href="Industries.php">Industries</a></li>
                <li><a href="Technologies.php">Technologies</a></li>
                <li><a href="#">Request Demo</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="Contact-Us.php">Contact Us</a></li>
            </ul>
        </nav>
    </div>
</header>