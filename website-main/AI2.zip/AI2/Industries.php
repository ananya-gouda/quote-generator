<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <title>AI</title>
        <meta content="" name="description">
        <meta content="" name="keywords">
        <link href="assets/img/favicon.png" rel="icon">
        <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
        <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
        <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
        <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
        <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
        <link href="assets/vendor/aos/aos.css" rel="stylesheet">
        <link href="assets/css/font-awesome.min.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
    </head>
    <body>

        <?php include_once './Header.php'; ?>

        <main id="main" data-aos="fade-up">
            <section class="breadcrumbs">
                <div class="container">
                    <div class="d-flex justify-content-between align-items-center">
                        <ol>
                            <li><a href="./">Home</a></li>
                            <li>Industries</li>
                        </ol>
                    </div>
                </div>
            </section>
            <section id="industries" class="inner-page industries">
                <div class="container" data-aos="fade-up">
                    <div class="section-title">
                        <h3>Industries</h3>
                        <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-sm-6 mb-4">
                        <div class="card border-0 shadow rounded-xs pt-5">
                            <div class="card-body"> <i class="fa fa-object-ungroup icon-lg icon-primary icon-bg-primary icon-bg-circle mb-3"></i>
                                <h4 class="mt-4 mb-3">Networking</h4>
                                <p>For what reason would it be advisable for me to think about business content?</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mb-4">
                        <div class="card border-0 shadow rounded-xs pt-5">
                            <div class="card-body"> <i class="fa fa-users icon-lg icon-yellow icon-bg-yellow icon-bg-circle mb-3"></i>
                                <h4 class="mt-4 mb-3">Social Activity</h4>
                                <p>For what reason would it be advisable for me to think about business content?</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mb-4">
                        <div class="card border-0 shadow rounded-xs pt-5">
                            <div class="card-body"> <i class="fa fa-desktop icon-lg icon-purple icon-bg-purple icon-bg-circle mb-3"></i>
                                <h4 class="mt-4 mb-3">Web Design</h4>
                                <p>For what reason would it be advisable for me to think about business content?</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mb-4">
                        <div class="card border-0 shadow rounded-xs pt-5">
                            <div class="card-body"> <i class="fa fa-cloud icon-lg icon-cyan icon-bg-cyan icon-bg-circle mb-3"></i>
                                <h4 class="mt-4 mb-3">Cloud Service</h4>
                                <p>For what reason would it be advisable for me to think about business content?</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mb-4">
                        <div class="card border-0 shadow rounded-xs pt-5">
                            <div class="card-body"> <i class="fa fa-comments icon-lg icon-red icon-bg-red icon-bg-circle mb-3"></i>
                                <h4 class="mt-4 mb-3">Consulting</h4>
                                <p>For what reason would it be advisable for me to think about business content?</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mb-4">
                        <div class="card border-0 shadow rounded-xs pt-5">
                            <div class="card-body"> <i class="fa fa-search-plus icon-lg icon-green icon-bg-green icon-bg-circle mb-3"></i>
                                <h4 class="mt-4 mb-3">SEO Optimization</h4>
                                <p>For what reason would it be advisable for me to think about business content?</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mb-4">
                        <div class="card border-0 shadow rounded-xs pt-5">
                            <div class="card-body"> <i class="fa fa-user icon-lg icon-orange icon-bg-orange icon-bg-circle mb-3"></i>
                                <h4 class="mt-4 mb-3">Usability Testing</h4>
                                <p>For what reason would it be advisable for me to think about business content?</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 mb-4">
                        <div class="card border-0 shadow rounded-xs pt-5">
                            <div class="card-body"> <i class="fa fa-envelope icon-lg icon-blue icon-bg-blue icon-bg-circle mb-3"></i>
                                <h4 class="mt-4 mb-3">UX Prototyping</h4>
                                <p>For what reason would it be advisable for me to think about business content?</p>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </section>
        </main>

        <?php include_once './Footer.php'; ?>

        <!-- Vendor JS Files -->
        <script src="assets/vendor/jquery/jquery.min.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
        <script src="assets/vendor/php-email-form/validate.js"></script>
        <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
        <script src="assets/vendor/counterup/counterup.min.js"></script>
        <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
        <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
        <script src="assets/vendor/venobox/venobox.min.js"></script>
        <script type="text/javascript" src="./assets/js/jssor.slider-28.0.0.min.js"></script>
        <script src="assets/vendor/aos/aos.js"></script>
        <script src="assets/js/main.js"></script>

    </body>

</html>